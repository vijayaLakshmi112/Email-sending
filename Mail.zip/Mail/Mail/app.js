const nodemailer = require('nodemailer');
const cron = require('node-cron');
const sql = require('mssql');

// Configure database connection
const dbConfig = {
  user: 'sa',       
  password: 'VijayaV@2003',   
  server: 'PC1\\SQLExpress',       
  database: 'employeeDB', 
  options: {
    encrypt: true, 
    trustServerCertificate: true, 
  },
};

// Configure email transporter
let transporter = nodemailer.createTransport({
  host: 'smtp-legacy.office365.com',
  port: 587,
  secure: false,
  auth: {
    user: 'vijayalakshmiv@sarasamerica.com',     
    pass: 'kxhvkgkdwjwgrrxl',        
  },
  tls: {
    ciphers: 'SSLv3',
  },
});

// Function to send birthday email
const sendBirthdayEmail = (employee) => {
  let mailOptions = {
    from: 'vijayalakshmiv@sarasamerica.com',
    to: employee.email,
    subject: `Happy Birthday ${employee.name}!`,
    text: `✨Wishing you a very Happy Birthday🎉, ${employee.name}!`,
    html: `
      <div style="text-align: center; font-family: Arial, sans-serif; color: #333;">
        <h1 style="color: #f28b22;">🎉 Happy Birthday ${employee.name}! 🎂</h1>
        <p>Wishing you a fantastic day filled with joy and a wonderful year ahead! 🎁🎈</p>
        <img src="https://img.freepik.com/premium-photo/all-happy-birthday-nice-image-use-ai-generator-ai-generator_1303953-10330.jpg?w=740" alt="Birthday wishes" style="width: 200px;">
        <p>Enjoy your special day! 🥳🎉</p>
      </div>`
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      return console.log(error);
    }
    console.log(`Birthday email sent to ${employee.name}: ` + info.response);
  });
};

// Function to fetch employees with birthdays from the database
const fetchEmployees = async () => {
  try {
    let pool = await sql.connect(dbConfig);
    const today = new Date().toISOString().slice(5, 10); 

    
    let result = await pool.request()
      .query(`SELECT name, email, FORMAT(birthday, 'MM-dd') as birthday FROM students WHERE FORMAT(birthday, 'MM-dd') = '${today}'`);

    return result.recordset; 
  } catch (err) {
    console.log('Database error:', err);
    return [];
  }
};


const checkBirthdays = async () => {
  console.log('Checking for birthdays...');
  const students = await fetchEmployees(); // Fetch employees from the database
  
  if (students.length === 0) {
    console.log('No birthdays today.');
    return;
  }

  students.forEach(employee => {
    console.log(`It's ${employee.name}'s birthday today! Sending email...`);
    sendBirthdayEmail(employee);
  });
};


cron.schedule('24 13 * * *', () => {
  checkBirthdays();
});

console.log('Birthday email scheduling service started...');
